To execute the simulation, please install the SIMULIDE (ChonGroup version) - https://github.com/chon-group/dpkg-simulide

In a terminal put the below commands:

echo "deb [trusted=yes] http://packages.chon.group/ chonos main" | sudo tee /etc/apt/sources.list.d/chonos.list
sudo apt update
sudo apt install chonos-simulide
